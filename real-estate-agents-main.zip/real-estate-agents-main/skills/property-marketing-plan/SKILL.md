---
name: property-marketing-plan
description: Create a complete property marketing plan and launch strategy for any listing. Use this skill whenever a user asks how to market a listing, what to post on social media for a property, how to plan a listing launch, what goes in a marketing plan, how to write a photography brief, or "how do I get this house sold." Also use when building a content calendar for a listing or briefing a photographer. Produces a full marketing plan with property story, target buyer profile, photography shot list, digital/print plan, and launch timeline.
---

# Property Marketing Plan

Produces a complete, channel-specific marketing plan for any residential listing — from property story through 30-day post-launch. This is Isabelle's work: every listing has one story, and every piece of content serves that story.

## What You Need From the User

- **Property:** address, price, beds/baths/SF, key features, standout details
- **Tier:** Entry ($300k–$700k) / Mid-Market ($700k–$2M) / Luxury ($2M+)
- **Timeline:** target list date, any deadline pressures
- **Agency's social channels:** Instagram, Facebook, YouTube, TikTok (check which apply)
- **Budget for paid ads:** rough range or "none"

If tier is unknown, infer from price. If price is unknown, ask.

## The Property Story (always first)

Before any tactics: define the ONE story this property tells. Not specs — story.

Ask yourself:
- What kind of life happens here?
- What is the ONE thing a buyer will remember after the showing?
- What does this home have that no comparable has?

Write 2–3 sentences. This becomes the headline for everything.

## Output Format

```markdown
## Property Marketing Plan
**Property:** [Address] | Listed at $[X]
**Tier:** [Entry / Mid-Market / Luxury]
**Prepared by:** Isabelle, Creative Director | [Date]
**Target List Date:** [Date]

---

### The Property Story
[2–3 sentences: the singular narrative. Not specs. The life. The feeling. The thing they'll remember.]

---

### Target Buyer Profile
**Primary buyer:** [Life stage, demographics, motivation, what they're searching for, how they find properties]
**Secondary buyer:** [Alternative profile]
**What they respond to:** [Lifestyle / investment / location / design]

---

### Photography & Video Brief

**Photographer:** [Name / TBD] | **Scheduled:** [Date, Time]
**Estimated duration:** [X] hours

#### Must-Have Shots (in priority order)
1. **Hero exterior** — [Specific angle: front elevation at golden hour / twilight / etc.]
2. **[Key room]** — Emphasize [light / scale / specific feature]. Shoot from [corner/angle].
3. **[Kitchen]** — [Wide + detail of [specific feature]. Include [styling element].]
4. **[Primary suite]** — [Direction, window inclusion, what to feature]
5. **[Outdoor / view / feature]** — [Specific framing note]
6. **Detail shot** — [Hardware / tile / built-in / architectural moment]
7. **Lifestyle implied** — [Table set, towels, flowers — specific prop note]

#### Video
[ ] Full cinematic (2–3 min) — for luxury/complex properties  
[ ] 60-sec Reels/TikTok walkthrough  
[ ] Agent-led tour (natural, conversational)  
[ ] None

#### Drone
[ ] Required (lot, location, or view justifies it)  
[ ] Optional  
[ ] Not applicable

#### Styling Notes for Shoot Day
[Specific: declutter X, add Y, move Z, seasonal flowers on Z, towels on rack in bath, etc.]

---

### Digital Marketing Plan

| Channel | Content | Targeting | Budget | Timeline |
|---------|---------|-----------|--------|----------|
| Instagram/FB | Carousel (5 slides) + Reels | [Geo radius + age/income demo] | $[X]/week | Launch day + [X] weeks |
| Zillow/Realtor | Enhanced listing + video | Active searchers in price range | $[X] | Ongoing |
| Email blast | Feature property email | Agency database ([X] contacts) | $0 | Launch day |
| Google Display | Retargeting | Site visitors | $[X]/week | Days 3–30 |
| YouTube | Cinematic video (if applicable) | In-market buyers geo-targeted | $[X] | Day 3 |

#### Social Content Plan (first 2 weeks)

| Day | Post | Format | Caption angle |
|-----|------|--------|---------------|
| -7 | Teaser | Stories | "Something special is coming to [neighborhood]..." |
| -3 | Coming Soon | Static + Stories | Property story headline + address reveal |
| 0 (Live) | Launch | Carousel | Full photo reveal, price, story copy |
| +2 | Video | Reels | 30–60 sec walkthrough |
| +5 | Open House | Static | Date/time, 1 hero photo |
| +7 | Lifestyle detail | Static | Single room, story caption |
| +14 | Performance/Social proof | Stories | Showing activity (without specifics) |

---

### Print & Physical Marketing

| Item | Quantity | Distribution | Notes |
|------|----------|--------------|-------|
| Just Listed postcards | [X] | [Radius / neighborhood farm] | Mail [X] days before list date |
| Property brochure | [X] | Open house + showing packets | [Size / paper stock] |
| Feature sheet | [X] | Lockbox / agent drop box | Single-page, price + highlights |
| Signage | Standard + [rider if applicable] | Install [X] days before list | |

---

### Open House Plan

**Date/Time:** [Day, Date] · [Time]  
**Broker Preview:** [Date, Time] — agent community first-look  
**Promotion:** Email blast [X] days prior + social posts [X] days prior + morning-of Stories  
**Refreshments:** [Light / None / Catered — depends on tier]  
**Staging additions for open house:** [Specific notes]

---

### Launch Timeline

| Day | Action | Owner |
|-----|--------|-------|
| -7 | Photographer briefed, shot list confirmed | Isabelle |
| -7 | "Coming Soon" social assets prepared | Isabelle |
| -5 | Pre-inspection complete, disclosures ready | TC / Listing Agent |
| -3 | "Coming Soon" posted across channels | Isabelle |
| -2 | Email blast scheduled | Isabelle |
| -1 | MLS entry drafted and reviewed by seller | Listing Agent |
| 0 | MLS active at [time] + social launch + email | All |
| +2 | Video/Reels published | Isabelle |
| +3 | Broker preview | Listing Agent |
| +7 | Open house | Listing Agent |
| +7 | Performance review: impressions, saves, showings | Isabelle |
| +14 | Budget / targeting adjustment if needed | Isabelle |

---

### Shot List by Tier Reference

**Entry ($300k–$700k):** 25–35 photos. All rooms including baths, exterior front + back, kitchen detail, primary suite, garage, standout feature.

**Mid-Market ($700k–$2M):** 35–50 photos + Reels. Above + lifestyle moments, twilight exterior, aerial if lot/location warrants, video walkthrough.

**Luxury ($2M+):** 50–75 photos + full cinematic video. Above + dedicated lifestyle shots, drone aerial and approach, architectural detail shots, materials and hardware close-ups.
```

## Behavior Notes

- Always write the Property Story before any tactics — if the story is weak, every channel suffers.
- If the user hasn't defined a tier, infer from price and ask only if genuinely ambiguous.
- For Entry tier: be decisive about cutting scope — not every entry listing needs a drone. State what's worth spending on and what isn't.
- For Luxury tier: never recommend skipping video. It's mandatory.
- If the user says "we have no budget for ads": cut the paid channels and make the email + organic social plan stronger.
- Always end with the launch timeline — this is what turns the plan into action.
