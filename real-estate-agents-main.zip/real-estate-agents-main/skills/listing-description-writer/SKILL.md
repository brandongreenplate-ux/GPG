---
name: listing-description-writer
description: Write compelling, story-first MLS listing descriptions and property marketing copy for any residential property. Use this skill whenever a user asks to write a listing description, property bio, MLS copy, listing blurb, or "what to say about this house." Also use when a user pastes specs and asks to make them sound good, or when existing copy is generic and needs rewriting. Produces copy that sells the lifestyle, not just the specs — in Marcus's voice: no clichés, no "charming," no "cozy."
---

# Listing Description Writer

Writes magnetic, story-first property descriptions that make buyers feel something — not just inform them. Every description starts with the life that happens inside, not the number of bedrooms.

## What You Need From the User

- **Property specs:** address (or city/neighborhood), beds, baths, SF, garage, lot
- **Standout features:** best rooms, views, outdoor space, architectural details, recent updates
- **Neighborhood/lifestyle context:** walkability, proximity to restaurants/transit/schools/parks
- **Tone target:** luxury / warm family / urban professional / investor / vacation
- **Length:** MLS short (~250 words) / full marketing (~400 words) / headline only

If only sparse info is given, write the best description possible and note what details would make it stronger.

## The Formula

Every description follows this structure — but never sounds formulaic:

1. **Hook (1 sentence):** The emotional pull. A lifestyle moment, a sensory detail, a standout feature. Never start with "Welcome to..." or "This stunning..."
2. **Architecture/Character (1–2 sentences):** What kind of home is this? What's its soul?
3. **Key Interior Moments (2–3 sentences):** The 2–3 spaces buyers fall in love with. Specific, vivid, present-tense.
4. **Practical Anchors (1 sentence):** Beds, baths, SF, garage — the specs that confirm it works, folded in naturally.
5. **Location & Lifestyle (1–2 sentences):** The neighborhood. What you can walk to. The feel of the street.
6. **Closer (1 sentence):** A forward-looking invitation. Never a command ("Don't miss this!"). Never urgency-bait.

## Banned Words & Phrases

Never use any of these — rewrite around them every time:
- charming, cozy, quaint, cute, adorable
- stunning, breathtaking, gorgeous, beautiful (show it, don't label it)
- nestled, boasts, features, offers
- "Welcome to your dream home"
- "Won't last long" / "Don't miss out"
- "Motivated seller"
- "As-is" (unless legally required)
- "Perfect for entertaining" (show the entertaining instead)

## Output Examples by Tier

### Entry-Level Example (~250 words)
```
Morning light hits the east-facing kitchen first — the kind of detail that sounds small 
until you've lived with it for a year. This well-maintained 1960s ranch in Eastwood has 
been updated where it counts: new roof (2022), refreshed kitchen with quartz countertops, 
and hardwood floors throughout the main level that refinish beautifully. Three bedrooms 
share a full bath upstairs; the finished basement adds a flexible fourth space for a home 
office, gym, or the guest room you've been promising. Two-car attached garage, fully fenced 
backyard, and a covered patio that earns its keep from April through October. Four blocks 
from the elementary school, two from the weekend farmers market. Offered at $[X].
```

### Luxury Example (~400 words)
```
The views from the great room don't require explanation — floor-to-ceiling glass frames 
the kind of panorama that stops a conversation. Perched on a private ridge in Hillcrest, 
this 2019 custom residence was built with the sightlines as the architecture. The open 
main level moves from the chef's kitchen — Wolf range, waterfall island, butler's pantry 
hidden behind cabinet-front doors — into a living space that scales for a dinner party 
or a quiet Sunday without feeling too large for either. The primary suite occupies its 
own wing: a spa bath with radiant floors, dual vanities, a soaking tub positioned where 
the light is right, and a closet that was clearly designed by someone who takes getting 
dressed seriously. Four additional bedrooms, each with en-suite baths, occupy the lower 
level alongside a home theater and a gym with direct access to the pool terrace. 
6 beds, 6.5 baths, 7,200 SF, three-car garage with EV charging. Ten minutes from 
downtown via the ridge road — close enough to use it, far enough to forget it exists. 
Offered at $[X].
```

## Behavior Notes

- Always write in third person, present tense — never first person, never past tense.
- If the user says "make it shorter," cut from the practical anchors section first. The hook and closer are sacred.
- If the user says "it sounds too fancy," dial back the vocabulary — not the structure. The story-first approach works at every price point.
- If the user wants a headline only (for social, email subject, etc.): write 3 options in different registers (evocative / direct / curiosity).
- After delivering the description, briefly note 1–2 things that would make it stronger if the user can provide more detail (e.g., "If you can tell me what's walkable from here, I can make the location section stronger").
